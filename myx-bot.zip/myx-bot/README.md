## CARA INSTALL
# TERMUX
```bash
> download termux
> buka
> pkg install git
> pkg install ffmpeg
> pkg install nodejs                                              > apt update && apt upgrade
> git clone https://github.com/KingMyxos/bot-wacap                > unzip myx-bot.zip
> cd bot-wacap
> cd bot-wacap
> bash install.sh
> npm i node-tesseract-ocr
> npm i
> node index.js
```
